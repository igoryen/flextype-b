---
title: Home
template: default
fieldset: default
menu_item_title: Home
menu_item_url: home
menu_item_target: _self
menu_item_order: '1'
uuid: 3d85291f-e2dd-4f96-8fd9-ecb797f11fdc
published_at: '10-09-2019 19:54'
created_at: '09/10/2019 07:54 pm'
published_by: fe26f824-db4a-49a1-8470-c1b788b9f473
description: ''
visibility: visible
routable: true
---
<h1 style="text-align: center;">Welcome!</h1>
<p style="text-align: center;" class="lead">
    Welcome to your new Flextype powered website.<br> Flextype is succesfully installed, you can start editing the content and customising your site in <a href="./admin">Admin panel</a>.
</p>
