# Admin Plugin for [Flextype](http://flextype.org/)
![MIT License](https://img.shields.io/badge/license-MIT-blue.svg?style=flat-square)

Admin Plugin for Flextype.

## LICENSE
[The MIT License (MIT)](https://github.com/flextype/flextype/blob/master/LICENSE.txt)
Copyright (c) 2018-2019 [Sergey Romanenko](https://github.com/Awilum)
