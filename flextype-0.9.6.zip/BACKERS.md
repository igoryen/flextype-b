<h1 align="center">Sponsors &amp; Backers</h1>

Flextype is an MIT-licensed open source project and completely free to use..

However, the amount of effort needed to maintain and develop new features for the project is not sustainable without proper financial backing. You can support it's ongoing development by being a backer or a sponsor:

- [Become a backer or sponsor on Patreon](https://www.patreon.com/awilum).
- [One-time donation via PayPal, QIWI, Sberbank, Yandex](http://flextype.org/en/one-time-donation)
- [Visit our Sponsors & Backers page](http://flextype.org/en/sponsors)
