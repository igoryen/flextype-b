## CONTRIBUTE
Flextype is an open source project and community contributions are essential to its growing and success. Contributing to the Flextype is easy and you can give as little or as much time as you want.

- Help on the [Communities.](http://flextype.org/en/community)
- Develop a new plugin.
- Create a new theme.
- Find and [report issues.](https://github.com/flextype/flextype/issues)
- Link back to [Flextype](http://flextype.org).
- [Donate to keep Flextype free.](http://flextype.org/en/sponsors)
- [Join Flextype International Translator Team](http://flextype.org/en/international-translator-team)
